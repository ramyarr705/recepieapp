package com.hotel.registration.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hotel.registration.model.RegisterBean;



public interface UserRepository extends JpaRepository<RegisterBean,Integer>  {


}
