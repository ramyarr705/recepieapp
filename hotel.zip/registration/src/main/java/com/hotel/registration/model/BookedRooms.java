package com.hotel.registration.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class BookedRooms {

	@Id
	private int customerId;
	private String customerEmailId;
	private String roomType;
	private int noOfPersons;
	private String fromDate;
	private String toDate;

	
	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public int getNoOfPersons() {
		return noOfPersons;
	}

	public void setNoOfPersons(int noOfPersons) {
		this.noOfPersons = noOfPersons;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public BookedRooms( int customerId, String customerEmailId, String roomType, int noOfPersons,
			String fromDate, String toDate) {
		super();
		
		this.customerId = customerId;
		this.customerEmailId = customerEmailId;
		this.roomType = roomType;
		this.noOfPersons = noOfPersons;
		this.fromDate = fromDate;
		this.toDate = toDate;
	}

	public BookedRooms() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getCustomerEmailId() {
		return customerEmailId;
	}

	public void setCustomerEmailId(String customerEmailId) {
		this.customerEmailId = customerEmailId;
	}

}
